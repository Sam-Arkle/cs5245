# ActionChains(driver).move_to_element(match_link).perform()
# driver.execute_script("arguments[0].scrollIntoView();", match_link)
# driver.find_element(By.LINK_TEXT, 'Match Report').click()
# options.profile.add_extension('ublock_origin-1.44.4.xpi')
# profile = webdriver.FirefoxProfile()
# profile_path = r"C:\Users\arklesd\AppData\Roaming\Mozilla\Firefox\Profiles\xhzq0jqp.default"
# profile.add_extension(extension='ublock_origin-1.44.4.xpi')
# driver = webdriver.Chrome()
# options.add_argument("window-size=1600x600")
# miscellaneous_link = driver.find_element(By.XPATH, '/html/body/div[2]/div[7]/div[6]/div[9]/a')

# table = driver.find_element(By.CSS_SELECTOR, "#div_matchlogs_for")
# table = driver.find_element(By.ID, 'matchlogs_for').find_elements(By.TAG_NAME, 'tr')
